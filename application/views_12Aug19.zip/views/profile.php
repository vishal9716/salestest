<?php echo $this->load->view("/common/top"); ?>
<html>
	<b> Profile </b>
	
	<div class="form-group">
                    <label>Full Name</label>

                    <div class="col-sm-10">
                      <input value="" class="" id="" name="" type="text">
                    
                    </div>
                  </div>
	<div class="form-group">
                    <label>Email</label>

                    <div class="col-sm-10">
                      <input value="" class="" id="" name="" type="text">
                    
                    </div>
                  </div>
    
	<div class="form-group">
                    <label>Photo</label>

                    <div class="col-sm-10">
                      <input value="" class="" id="" name="" type="text">
                    
                    </div>
                  </div>
	<div class="form-group">
                    <label>Photo</label>

                    <div class="col-sm-10">
                      <input value="" class="" id="" name="" type="text">
                    
                    </div>
                  </div>
	<div class="form-group">
                    <label>User Role</label>

                    <div class="col-sm-10">
                      <input value="" class="" id="" name="" type="text">
                    
                    </div>
                  </div>
	
	
	<button>update</button>
</html>

